var docs=document.getElementById("doks");
var btn=document.getElementById("show");
console.log(docs.className);
btn.onclick=function ()
{
if(docs.className=="para_closed")
{
    docs.className="para_open";
    btn.innerHTML="Show Less";
}
else
{
    docs.className="para_closed";
    btn.innerHTML="Show More"
}

}



